#pragma once

#include "ofMain.h"
#include "ofxOsc.h"
#include "ofxGui.h"

// listening port
#define PORT1 7771
#define PORT2 7772
#define HISTORY 5

// max number of strings to display
#define NUM_MSG_STRINGS 20

// demonstrates receiving and processing OSC messages with an ofxOscReceiver,
// use in conjunction with the oscSenderExample
class ofAppOSCArduinoSimple : public ofBaseApp{
	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y);
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);

		ofxOscReceiver receiver1, receiver2;

		ofxPanel gui1, gui2;
		ofxFloatSlider delta1, theta1, lowalpha1, attention1;
		ofxFloatSlider delta2, theta2, lowalpha2, attention2;
		float history1[HISTORY], history2[HISTORY];
		int ind1 = 0, ind2 = 0;

		//Arduino Control.
		ofSerial serial;
};