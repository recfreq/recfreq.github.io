﻿//Reads from BrainWaveOSC.exe or any other OSC sender on port specified in OSC1.cs and OSC2.cs.
//Currently used to read from NeuroSky via BrainWaveOSC.
//Requires OSC.cs distribution, which is referenced to the public object below.
//Requires C:\parsons\course_2018fa\course_datamaterial\whartif\arduino\MotorControlRay02Serial
//         Arduino code for controlling water pumps to blow up balloons.
//Use: make an empty object with this script and drag OSC object (which has OSC.cs on it) to here,
//     you should have two empty objects, one with OSC.cs on it, one with this script on it,
//     currently only displays data, use this script as template for other OSC reads in game.
//Be sure to do "\n" to terminate any message sent through using Serial.
//2061 next Halley's Comet coming.

using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.IO.Ports;

public class TelewaveOSCArduinoEEG : MonoBehaviour {

	//OSC communication to get EEG data.
	public OSC osc1, osc2;  //On port 7771 and 7772.
	float delta1, theta1, lowalpha1, delta2, theta2, lowalpha2;
	float attention1, attention2;

	//Arduino control of air pumps.
	SerialPort sp;
	float total1 = 0.0f, total2 = 0.0f;

	//Drawing.
	public Material mat1, mat2;
	public Text balloon1, balloon2;

	// Use this for initialization
	void Start () {
		/*osc1.SetAddressHandler("/eegdelta", GetDelta1);
		osc1.SetAddressHandler("/eegtheta", GetTheta1);
		osc1.SetAddressHandler("/eeglowalpha", GetLowAlpha1);*/
		//osc1.SetAddressHandler("/attention", GetAttention1);
		/*osc2.SetAddressHandler("/eegdelta", GetDelta2);
		osc2.SetAddressHandler("/eegtheta", GetTheta2);
		osc2.SetAddressHandler("/eeglowalpha", GetLowAlpha2);*/
		//osc2.SetAddressHandler("/attention", GetAttention2);

		//need to set player settings: Configuration->Scripting Runtime Version to Experimental .NET 4.6.
		sp = new SerialPort ("\\\\.\\COM41", 9600);  //for Arduino Uno on right side.
		sp.Open ();
	}

	// Update is called once per frame
	void Update () {
		if (Input.GetKeyUp (KeyCode.F)) {
			//sp.Write ("1, 255");
			sp.Write("1, 255\n");
			mat1.SetFloat ("_Metallic", 0.8f);
			Debug.Log ("pump 1 on");
			balloon1.text = "1 ON";
		}
		if (Input.GetKeyUp (KeyCode.G)) {
			sp.Write ("2, 255\n");
			mat2.SetFloat ("_Metallic", 0.8f);
			Debug.Log ("pump 2 on");
			balloon2.text = "2 ON";
		}
		if (Input.GetKeyUp (KeyCode.D)) {
			sp.Write ("1, 0\n");
			mat1.SetFloat ("_Metallic", 0.0f);
			mat2.SetFloat ("_Metallic", 0.0f);
			balloon1.text = "";
			balloon2.text = "";
		}
		if (Input.GetKeyUp (KeyCode.S)) {
			sp.Write ("1, 1\n");
		}
	}

	void GetDelta1 (OscMessage message){
		delta1 = message.GetFloat(0);
		Debug.Log ("delta1: " + delta1);
	}

	void GetTheta1 (OscMessage message) {
		theta1 = message.GetFloat(0);
		Debug.Log ("theta1: " + theta1);
	}

	void GetLowAlpha1 (OscMessage message) {
		lowalpha1 = message.GetFloat(0);
		Debug.Log ("lowalpha1: " + lowalpha1);
	}

	void GetAttention1 (OscMessage message) {
		attention1 = message.GetFloat (0);
		Debug.Log ("attention1: " + attention1);
		if (attention1 < 28) {
			sp.Write ("1, 200\n");
		} else {
			sp.Write ("1, 255\n");
		}
		total1 += attention1;
		balloon1.text = "" + total1;
	}

	void GetDelta2 (OscMessage message){
		delta2 = message.GetFloat(0);
		Debug.Log ("delta2: " + delta2);
	}

	void GetTheta2 (OscMessage message) {
		theta2 = message.GetFloat(0);
		Debug.Log ("theta2: " + theta2);
	}

	void GetLowAlpha2 (OscMessage message) {
		lowalpha2 = message.GetFloat(0);
		Debug.Log ("lowalpha2: " + lowalpha2);
	}

	void GetAttention2 (OscMessage message) {
		attention2 = message.GetFloat(0);
		Debug.Log ("attention2: " + attention2);
		if (attention2 < 28) {
			sp.Write ("2, 200\n");
		} else {
			sp.Write ("2, 255\n");
		}
		total2 += attention2;
		balloon2.text = "" + total2;
	}
}