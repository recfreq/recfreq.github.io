﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.IO.Ports;

public class Arduino : MonoBehaviour {

	public GameObject player;
	public Material mat1, mat2;
	SerialPort sp;
	string inString;
	float v1, v2;

	void Start () {
		//need to set player settings: Configuration->Scripting Runtime Version to Experimental .NET 4.6.
		sp = new SerialPort ("\\\\.\\COM41", 9600);  //for Arduino Uno on right side.
		sp.Open ();
	}

	void Update () {
		//UNITY TO ARDUINO.
		if (Input.GetKeyUp (KeyCode.F)) {
			sp.Write ("f");
			mat1.SetFloat ("_Metallic", 0.8f);
		}
		if (Input.GetKeyUp (KeyCode.S)) {
			sp.Write ("s");
			mat1.SetFloat ("_Metallic", 0.0f);
		}
		if (Input.GetKeyUp (KeyCode.V)) {
			sp.Write ("v");
			mat2.SetFloat ("_Metallic", 0.8f);
		}
		if (Input.GetKeyUp (KeyCode.X)) {
			sp.Write ("x");
			mat2.SetFloat ("_Metallic", 0.0f);
		}

		//ARDUINO TO UNITY.
		//Reading microphone data in the "v1, v2" format, v1 for neopixel controlled by f&s, v2 for controlled by v&x .
		while (sp.BytesToRead > 0) {
			int c = sp.ReadByte ();
			if (c == '\n') {
				Debug.Log (inString);
				string[] parts = inString.Split (',');
				if (parts.Length == 2) {
					v1 = float.Parse (parts [0]);  //convert string to int.
					v2 = float.Parse (parts [1]);
					Debug.Log (v1 + ", " + v2);
				}
				inString = "";
			} else {
				inString += (char)c;  //cast int into char.
			}
		}

		if (v1 > 0.9) {
			sp.Write ("f");
			mat1.SetFloat ("_Metallic", 0.8f);
		} else {
			sp.Write ("s");
			mat1.SetFloat ("_Metallic", 0.0f);
		}
		if (v2 > 0.4) {
			sp.Write ("v");
			mat2.SetFloat ("_Metallic", 0.8f);
		} else {
			sp.Write ("x");
			mat2.SetFloat ("_Metallic", 0.0f);
		}
	}
}