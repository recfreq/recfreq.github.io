#include "ofAppOSCArduinoSimple.h"

//--------------------------------------------------------------
void ofAppOSCArduinoSimple::setup(){
	ofBackground(0);
	ofSetFrameRate(60);
	// listen on the given port
	receiver1.setup(PORT1);
	receiver2.setup(PORT2);

	gui1.setup();
	gui1.setPosition(0, 300);
	/*gui1.add(delta1.setup("delta", 0, 0, 20000));
	gui1.add(theta1.setup("theta", 0, 0, 20000));
	gui1.add(lowalpha1.setup("lowalpha", 0, 0, 20000));
	gui1.add(attention1.setup("attention", 0, 0, 100));*/
	//Fake names for the params.
	gui1.add(delta1.setup("delta", 0, 0, 20000));
	gui1.add(theta1.setup("theta", 0, 0, 20000));
	gui1.add(lowalpha1.setup("lowalpha", 0, 0, 20000));
	gui1.add(attention1.setup("attention", 0, 0, 100));
	gui2.setup();
	gui2.setPosition(720, 300);
	gui2.add(delta2.setup("delta", 0, 0, 20000));
	gui2.add(theta2.setup("theta", 0, 0, 20000));
	gui2.add(lowalpha2.setup("lowalpha", 0, 0, 20000));
	gui2.add(attention2.setup("attention", 0, 0, 100));

	//Arduino Control.
	//Using port to the right of the computer on Arduino Uno with COM34.
	//serial.setup("COM34", 9600);
	//serial.listDevices();
	ofSetLogLevel(OF_LOG_VERBOSE);
	if (!serial.setup("COM34", 9600)) {
		// log and error and leave.
		ofLog() << "could not open serial port - listing serial devices";
		serial.listDevices();
		//OF_EXIT_APP(0);
	}
}

//--------------------------------------------------------------
void ofAppOSCArduinoSimple::update(){
	ofxOscMessage m1, m2;
	while (receiver1.hasWaitingMessages()) {
		receiver1.getNextMessage(m1);
		ofLog() << "    address1: " << m1.getAddress();
		if (m1.getAddress() == "/eegdelta") {
			delta1 = m1.getArgAsFloat(0);
		}
		if (m1.getAddress() == "/eegtheta") {
			theta1 = m1.getArgAsFloat(0);
		}
		if (m1.getAddress() == "/eeglowalpha") {
			lowalpha1 = m1.getArgAsFloat(0);
		}
		if (m1.getAddress() == "/attention") {
			attention1 = m1.getArgAsFloat(0);
			if (attention1 != history1[(ind1 - 1 + HISTORY) % HISTORY]) {
				history1[ind1] = attention1;
				ind1 = (ind1 + 1) % HISTORY;
			}
		}
	}
	while (receiver2.hasWaitingMessages()) {
		receiver2.getNextMessage(m2);
		ofLog() << "    address2: " << m2.getAddress();
		if (m2.getAddress() == "/eegdelta") {
			delta2 = m2.getArgAsFloat(0);
		}
		if (m2.getAddress() == "/eegtheta") {
			theta2 = m2.getArgAsFloat(0);
		}
		if (m2.getAddress() == "/eeglowalpha") {
			lowalpha2 = m2.getArgAsFloat(0);
		}
		if (m2.getAddress() == "/attention") {
			attention2 = m2.getArgAsFloat(0);
			if (attention2 != history2[(ind2 - 1 + HISTORY) % HISTORY]) {
				history2[ind2] = attention2;
				ind2 = (ind2 + 1) % HISTORY;
			}
		}
	}
}

//--------------------------------------------------------------
void ofAppOSCArduinoSimple::draw(){
	ofSetColor(ofMap(lowalpha1, 0, 20000, 0, 255), 100, 100);
	ofDrawRectangle(320, 0, 400, 400);
	ofSetColor(ofMap(lowalpha2, 0, 20000, 0, 255), 100, 100);
	ofDrawRectangle(1040, 0, 400, 400);
	if (attention1 > 48) {
		ofSetColor(255);
		serial.writeByte('f');  //On light your side.
		serial.writeByte('x');  //Off light opposite side.
	}
	else {
		ofSetColor(50);
		serial.writeByte('s');  //Off light your side.
		serial.writeByte('v');  //On light opposite side.
	}
	ofDrawCircle(520, 200, attention1 * 2);
	if (attention2 >48) {
		ofSetColor(255);
	}
	else {
		ofSetColor(50);
	}
	ofDrawCircle(1240, 200, attention2 * 2);

	ofSetColor(255);
	gui1.draw();
	gui2.draw();
	for (int k = 0; k < HISTORY; k++) {
		ofDrawBitmapString("history1 " + ofToString(k) + ": " + ofToString(history1[k]), 205, 310+20*k);
	}
	for (int k = 0; k < HISTORY; k++) {
		ofDrawBitmapString("history2 " + ofToString(k) + ": " + ofToString(history2[k]), 925, 310+20*k);
	}
}

//--------------------------------------------------------------
void ofAppOSCArduinoSimple::keyPressed(int key){
	if (key == 'f') {
		serial.writeByte('f');
	}
	else if (key == 'v') {
		serial.writeByte('v');
	}

}

//--------------------------------------------------------------
void ofAppOSCArduinoSimple::keyReleased(int key){
	serial.writeByte('s');
	serial.writeByte('x');
}

//--------------------------------------------------------------
void ofAppOSCArduinoSimple::mouseMoved(int x, int y){

}

//--------------------------------------------------------------
void ofAppOSCArduinoSimple::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofAppOSCArduinoSimple::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofAppOSCArduinoSimple::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofAppOSCArduinoSimple::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofAppOSCArduinoSimple::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofAppOSCArduinoSimple::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofAppOSCArduinoSimple::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofAppOSCArduinoSimple::dragEvent(ofDragInfo dragInfo){

}